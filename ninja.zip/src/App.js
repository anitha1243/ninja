import React from 'react';
import { Map, Marker, Popup, TileLayer } from "react-leaflet";
import './App.css';
import * as parkData from "./location.json";

function App() {
  return <Map center={[-37.788706,144.823430]} zoom={12}>
  <TileLayer
    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
    attribution= '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a>
    contributors'
    />

    {parkData.features.map(park => (
        <Marker
          key={park.properties.PARK_ID}
          position={[
            park.geometry.coordinates[0],
            park.geometry.coordinates[1]
          ]}

        />
      ))}

  </Map>;
}

export default App;
